use [pubs]
-- 6) Show the sql to find all the titles with more than one author.

select ti.title_id,ti.title
from [dbo].[titles] as ti
inner join [dbo].[titleauthor] as ta
on ti.title_id=ta.title_id
inner join [dbo].[authors] as au
on ta.au_id=au.au_id
group by ti.title_id,ti.title
having count(ti.title_id)>1

--7)Show the sql to show all the authors with more than one book

select a.au_fname [First Name], a.au_lname [Last Name]
from authors a
inner join titleauthor ta
on a.au_id = ta.au_id
group by a.au_fname, a.au_lname
having count(ta.title_id) >1

--8)Show the sql to show the publishers with no titles

select p.pub_id, p.pub_name, t.title_id, t.title
from publishers p
left join titles t
on p.pub_id = t.pub_id
where p.pub_id not in (select ti.pub_id from titles ti
inner join publishers p
on ti.pub_id = p.pub_id)
